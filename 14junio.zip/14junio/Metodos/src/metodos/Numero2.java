/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

import java.util.Scanner;

/**
 *
 * @author ricardo
 */
public class Numero2 {

    public static void main(String[] args) {

        Presenta imprimir = new Presenta(); // El objeto imprimir tipo Presenta

        Scanner teclado = new Scanner(System.in); // El teclado tipo Scanner

        System.out.println("Ingrese su nmbre:"); // Imprimir pantalla

        String minombre = teclado.nextLine(); // Asigna el valor al nombre

        System.out.println("Tipo de reporte 1 --- 2");

        int tipo = teclado.nextInt();

        imprimir.impresion(tipo, minombre);

    }
}