/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

/**
 *
 * @author ricardo
 */
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

        Operacion imprimir = new Operacion(); // Objeto imprimir clase Operación
        Scanner teclado = new Scanner(System.in);

        // Se asigna el primer valor a prinumero.
        System.out.println("Ingrese primer numero:");
        int prinumero = teclado.nextInt();

        // Se asigna el segundo valor a segunumero.
        System.out.println("Ingrese primer numero:");
        int segunumero = teclado.nextInt();
        
        // Se asigna el tipo de calculo.
        System.out.println("(1)SUMA\n(2)RESTA\n(3)Multiplicación\n(4)División\n\n Seleccione TIPO:");
        int tipo = teclado.nextInt();
        
        // Se envia los datos al metodo calculo.
        imprimir.calculo(tipo, prinumero, segunumero);
    }

}
