/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

/**
 *
 * @author ricardo
 */
public class Operacion {
    
    // Metodo suma.

    public void suma(int numero1, int numero2) {

        int suma = numero1 + numero2;
        // Imprime pantalla.
        System.out.printf("La suma de %d más %d\nes igual a\n\t%d\n", numero1, numero2, suma);
    }
    
    // Metodo resta.

    public void resta(int numero1, int numero2) {

        int resta = numero1 - numero2;
        // Imprime pantalla.
        System.out.printf("La resta de %d menos %d\nes igual a\n\t%d\n", numero1, numero2, resta);
    }
    
    // Metodo Multipliacion.

    public void multiplicacion(int numero1, int numero2) {

        int multiplicacion = numero1 * numero2;
        // Imprime pantalla.
        System.out.printf("La multiplicación de %d x %d\nes igual a\n\t%d\n", numero1, numero2, multiplicacion);
    }
    
    // Metodo division.

    public void division(int numero1, int numero2) {

        int division = numero1 / numero2;
        // Imprime pantalla.
        System.out.printf("La division de %d : %d\nes igual a\n\t%d\n", numero1, numero2, division);
    }
    
    // Metodo calculo.

    public void calculo(int opcion, int numero1, int numero2) {
        
        // Incia condicion para cada Tipo de calculo.
        if (opcion == 1) {
            suma(numero1, numero2); // Se incoca al metodo suma.
        } else {
            if (opcion == 2) {
                resta(numero1, numero2); // Se incoca al metodo resta.
            } else {
                if (opcion == 3) {
                    multiplicacion(numero1, numero2); // Se incoca al metodo multiplicacion.
                } else {
                    if (opcion == 4) {
                        division(numero1, numero2); // Se incoca al metodo division.
                    }
                }
            }
        }
    }

}
