/*
 * Autor: Ricardo Paltin
 * Clase 3 (semana 3)
 */
package metodos;

/**
 *
 * @author ricardo
 */
import java.util.Scanner;

public class Presentar {
    
     public static void main(String[] args) {
         
         Presenta imprimir = new Presenta(); // El objeto imprimir tipo Presenta
         
         Scanner teclado = new Scanner(System.in); // El teclado tipo Scanner
         
         System.out.println("Ingrese su nmbre:"); // Imprimir pantalla
         
         String minombre = teclado.nextLine(); // Asigna el valor al 
         
         System.out.println("Tipo de reporte 1 --- 2");
         
         int tipo = teclado.nextInt();
         
         if (tipo == 1){
             
             imprimir.presentar_mayusculas(minombre);
         }else{
             if (tipo ==2){
                 imprimir.presentar_minusculas(minombre);
             }else{
                 System.out.println("No hay reporte");
             }
             
         }
         
     }
    
}
