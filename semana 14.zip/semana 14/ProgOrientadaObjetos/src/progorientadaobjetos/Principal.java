/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progorientadaobjetos;

/**
 *
 * @author ricardo
 */
public class Principal {
    public static void main(String[] args) {
        // mi clase "contenedor" = Estudiante...... Objeto = e1 y e2
        Estudiante e1 = new Estudiante();
        Estudiante e2 = new Estudiante();
        
        int suma_edades = 0;
        double promedio = 0;
        
        e1.nombre = "luis";
        e2.nombre = "Maria";
        
        e1.edad = 18;
        e2.edad = 17;
        
        suma_edades = e1.edad + e2.edad;
        promedio = (double)suma_edades / 2;
                
        System.out.println(promedio);
    }
    
}
