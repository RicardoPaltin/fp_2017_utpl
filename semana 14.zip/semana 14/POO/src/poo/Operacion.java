/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author ricardo
 */
public class Operacion {
    
    private int lado;
    
    // metodos public void agregar_lado
    public void agregar_lado(int l){
        
        lado = l;
        
    }
    public int obtener_lado(){
        
        return lado;
        
    }
    public int calcular_area(){
        
        // int area = lado * lado; la otra es correcta >> int area1 = obtener_lado() * obtener_lado();
        int area1 = obtener_lado() * obtener_lado();
        return area1;
    }
    public int calcular_perimetro(){
        int perimetro = obtener_lado()+ obtener_lado()+ obtener_lado() + obtener_lado();
        return perimetro;
        
    }
    
}
