/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author ricardo
 */
import java.util.Scanner;

public class Cuadrado {
    
    public static void main(String[] args) {
        
        Scanner e = new Scanner(System.in);
        
        for(int i = 1; i <= 5; i++){
            System.out.println("Agrese valor de lado: ");
            int lado = e.nextInt();
            Operacion c = new Operacion();
            c.agregar_lado(lado);
            System.out.printf("Cuadrado con lad5o %d\n\tArea = %d\n\tPerimetro = %d\n", c.obtener_lado(), c.calcular_area(),c.calcular_perimetro());
            
            
            
            
        }
    }
}
