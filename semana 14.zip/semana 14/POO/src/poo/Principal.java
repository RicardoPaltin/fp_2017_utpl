/*
 * segunda parte privados
 */
package poo;

/**
 *
 * @author Sistemas
 */
public class Principal {

    public static void main(String[] args) {
        // mi clase "contenedor" = Estudiante...... Objeto = e1 y e2
        Estudiante2 e1 = new Estudiante2();
        Estudiante2 e2 = new Estudiante2();
        
        int suma_edades;
        double promedio;


        String valor_nombre = "Luis";
        
        e1.agregar_nombre(valor_nombre);
        e2.agregar_nombre("Maria");
        
        e1.agregar_edad(20);
        e2.agregar_edad(17);
        
        suma_edades = e1.obtener_edad() + e2.obtener_edad() ;
        promedio = (double)suma_edades/2;

        System.out.println(promedio);
    }
}
