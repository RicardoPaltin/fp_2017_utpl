/*
 * NO me funciono se corrigio con otra classe Estudinte2
 */
package poo;

/**
 *
 * @author Sistemas
 */
public class Estudiante {

//    private String nombre;
//    private int edad;
//
//    public void agregar_nombre(String n) { // para los privados
//
//        nombre = n;
//    }
//
//    public String obtener_nombre() {
//        return nombre;
//    }
//    public void agregar_edad(int e){
//        edad = e;
//    }
//    public int obtener_edad(){
//        return edad;
}
